/*
 * palette_test.h
 *
 *  Created on: Apr 6, 2022
 *      Author: zcheng1
 */

#ifndef PALETTE_TEST_H_
#define PALETTE_TEST_H_



void paletteTest(); //call this function before your main test function for Week 2

#endif /* PALETTE_TEST_H_ */
