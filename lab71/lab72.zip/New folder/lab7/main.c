#include <stdio.h>
#include "text_mode_vga_color.h"
#include "palette_test.h"



int main(){
	//paletteTest();
	textVGAColorScreenSaver();
	return 0;
}
