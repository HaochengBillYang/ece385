#include <stdio.h>
#include "text_mode_vga.h"



int main(){
	textVGATest();
	return 0;
}
